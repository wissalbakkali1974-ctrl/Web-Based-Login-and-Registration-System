<div class="login-container">
    <h1>Welcome</h1>

    <p>Hey, <strong><?php echo $_SESSION['user_name']; ?></strong>. You are logged in.</p>

    <a href="index.php?logout" class="logout-btn">Logout</a>
</div>
