<div class="login-container">

    <h1>Login</h1>

    <?php
    if (isset($login)) {
        if ($login->errors) {
            foreach ($login->errors as $error) {
                echo '<div class="error">'.$error.'</div>';
            }
        }
        if ($login->messages) {
            foreach ($login->messages as $message) {
                echo '<div class="message">'.$message.'</div>';
            }
        }
    }
    ?>

    <form method="post" action="index.php" name="loginform">

        <label>Username</label>
        <input type="text" name="user_name" required>

        <label>Password</label>
        <input type="password" name="user_password" required>

        <input type="submit" name="login" value="Log in">
    </form>

    <a href="register.php">Register new account</a>

</div>
